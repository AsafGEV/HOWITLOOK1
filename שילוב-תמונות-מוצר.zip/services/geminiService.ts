import { GoogleGenAI, Modality } from "@google/genai";

if (!process.env.API_KEY) {
  throw new Error("API_KEY environment variable is not set");
}

const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });

const fileToGenerativePart = (base64: string, mimeType: string) => {
  return {
    inlineData: {
      data: base64,
      mimeType
    },
  };
};

export const mergeImages = async (
  locationImageBase64: string,
  locationImageMimeType: string,
  productImageBase64: string,
  productImageMimeType: string,
  annotatedLocationImageBase64?: string | null,
  annotatedLocationImageMimeType?: string | null
): Promise<string> => {
  try {
    const model = 'gemini-2.5-flash-image-preview';
    const productPart = fileToGenerativePart(productImageBase64, productImageMimeType);
    let promptText: string;
    let parts: any[];

    if (annotatedLocationImageBase64 && annotatedLocationImageMimeType) {
      const annotatedLocationPart = fileToGenerativePart(annotatedLocationImageBase64, annotatedLocationImageMimeType);
      const originalLocationPart = fileToGenerativePart(locationImageBase64, locationImageMimeType);
      
      promptText = `The first image is a background with a red ellipse indicating a target area. The second image is the original, clean version of the background. The third image is a product.
      Realistically place the product from the third image into the clean background (second image), using the red ellipse in the first image as a precise guide for placement, scale, and orientation.
      The final output image must be seamless and must NOT contain the red ellipse.`;
      
      parts = [annotatedLocationPart, originalLocationPart, productPart, { text: promptText }];
    } else {
      const locationPart = fileToGenerativePart(locationImageBase64, locationImageMimeType);
      
      promptText = `Take the second image (the product) and realistically place it inside the first image (the background location). 
         Ensure the product's appearance is preserved perfectly. 
         Adjust lighting, shadows, and scale to make the integration seamless and natural.`;
      
      parts = [locationPart, productPart, { text: promptText }];
    }
    
    const response = await ai.models.generateContent({
        model: model,
        contents: {
            parts: parts,
        },
        config: {
            responseModalities: [Modality.IMAGE, Modality.TEXT],
        },
    });

    for (const part of response.candidates[0].content.parts) {
        if (part.inlineData && part.inlineData.mimeType.startsWith('image/')) {
            return part.inlineData.data;
        }
    }

    throw new Error("No image was returned from the API.");

  } catch (error) {
    console.error("Error calling Gemini API:", error);
    if (error instanceof Error) {
        throw new Error(`Failed to merge images: ${error.message}`);
    }
    throw new Error("An unknown error occurred while merging images.");
  }
};