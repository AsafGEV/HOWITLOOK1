
import React, { useRef, useEffect, useState, useCallback } from 'react';

interface ImageAreaSelectorProps {
  id: string;
  title: string;
  image: string | null; // data URL
  onImageSelect: (file: File) => void;
  onImageRemove: () => void;
  onAreaSelected: (base64: string, mimeType: string) => void;
}

const ImageAreaSelector: React.FC<ImageAreaSelectorProps> = ({ id, title, image, onImageSelect, onImageRemove, onAreaSelected }) => {
    const fileInputRef = useRef<HTMLInputElement>(null);
    const canvasRef = useRef<HTMLCanvasElement>(null);
    const imageRef = useRef<HTMLImageElement | null>(null);
    
    const [isDrawing, setIsDrawing] = useState(false);
    const [startPoint, setStartPoint] = useState<{ x: number; y: number } | null>(null);
    const [endPoint, setEndPoint] = useState<{ x: number; y: number } | null>(null);
    const [showInstructions, setShowInstructions] = useState(true);

    const handleFileChange = (event: React.ChangeEvent<HTMLInputElement>) => {
        const file = event.target.files?.[0];
        if (file) {
            onImageSelect(file);
        }
    };

    const handleRemoveClick = (event: React.MouseEvent<HTMLButtonElement>) => {
        event.stopPropagation();
        onImageRemove();
        if(fileInputRef.current) {
            fileInputRef.current.value = "";
        }
    };

    const redrawCanvas = useCallback((circleStart, circleEnd) => {
        const canvas = canvasRef.current;
        const ctx = canvas?.getContext('2d');
        const img = imageRef.current;
        if (!canvas || !ctx || !img) return;

        ctx.clearRect(0, 0, canvas.width, canvas.height);
        ctx.drawImage(img, 0, 0);

        if (circleStart && circleEnd) {
            const centerX = (circleStart.x + circleEnd.x) / 2;
            const centerY = (circleStart.y + circleEnd.y) / 2;
            const radiusX = Math.abs(circleEnd.x - circleStart.x) / 2;
            const radiusY = Math.abs(circleEnd.y - circleStart.y) / 2;

            ctx.strokeStyle = 'rgba(239, 68, 68, 0.9)'; // Red color
            ctx.lineWidth = Math.max(5, (img.width + img.height) / 300);
            ctx.beginPath();
            ctx.ellipse(centerX, centerY, radiusX, radiusY, 0, 0, 2 * Math.PI);
            ctx.stroke();
        }
    }, []);

    const getCanvasPoint = (e: React.MouseEvent<HTMLCanvasElement>): { x: number; y: number } | null => {
        const canvas = canvasRef.current;
        if (!canvas) return null;
        const rect = canvas.getBoundingClientRect();
        const scaleX = canvas.width / rect.width;
        const scaleY = canvas.height / rect.height;
        return {
            x: (e.clientX - rect.left) * scaleX,
            y: (e.clientY - rect.top) * scaleY,
        };
    };

    const handleMouseDown = (e: React.MouseEvent<HTMLCanvasElement>) => {
        const point = getCanvasPoint(e);
        if (!point) return;
        setIsDrawing(true);
        setStartPoint(point);
        setEndPoint(point);
        setShowInstructions(false);
    };
    
    const handleMouseMove = (e: React.MouseEvent<HTMLCanvasElement>) => {
        if (!isDrawing) return;
        const point = getCanvasPoint(e);
        if (!point) return;
        setEndPoint(point);
        redrawCanvas(startPoint, point);
    };

    const handleMouseUp = () => {
        if (!isDrawing || !canvasRef.current || !startPoint || !endPoint) return;
        setIsDrawing(false);
        
        redrawCanvas(startPoint, endPoint);

        const canvas = canvasRef.current;
        // Using image/png to preserve transparency and quality of the drawn circle
        const dataUrl = canvas.toDataURL('image/png'); 
        const base64 = dataUrl.split(',')[1];
        onAreaSelected(base64, 'image/png');
    };

    useEffect(() => {
        const canvas = canvasRef.current;
        const ctx = canvas?.getContext('2d');
        if (!image || !canvas || !ctx) return;

        const img = new Image();
        img.src = image;
        img.onload = () => {
            imageRef.current = img;
            canvas.width = img.naturalWidth;
            canvas.height = img.naturalHeight;
            ctx.drawImage(img, 0, 0, img.naturalWidth, img.naturalHeight);
            setShowInstructions(true);
            setStartPoint(null);
            setEndPoint(null);
        };
        img.onerror = () => {
            console.error("Failed to load image into canvas editor.");
        }
    }, [image]);

    return (
        <div className="w-full">
            <label htmlFor={id} className="block text-sm font-medium text-gray-300 mb-2">{title}</label>
            {image ? (
                <div className="relative group">
                    {showInstructions && (
                         <div className="absolute inset-x-0 top-0 z-10 p-2 bg-black bg-opacity-60 text-center text-sm text-white pointer-events-none rounded-t-md">
                            לחץ וגרור על התמונה כדי לסמן איפה למקם את המוצר
                         </div>
                    )}
                    <canvas 
                        ref={canvasRef}
                        className="w-full h-auto rounded-md cursor-crosshair"
                        onMouseDown={handleMouseDown}
                        onMouseMove={handleMouseMove}
                        onMouseUp={handleMouseUp}
                        onMouseLeave={handleMouseUp} // End drawing if mouse leaves canvas
                    />
                    <div className="absolute top-2 right-2 opacity-50 group-hover:opacity-100 transition-opacity">
                         <button 
                            onClick={handleRemoveClick}
                            className="bg-red-600 text-white rounded-full p-2 hover:bg-red-700 shadow-lg"
                            aria-label="Remove image"
                        >
                            <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 7l-.867 12.142A2 2 0 0116.138 21H7.862a2 2 0 01-1.995-1.858L5 7m5 4v6m4-6v6m1-10V4a1 1 0 00-1-1h-4a1 1 0 00-1 1v3M4 7h16" />
                            </svg>
                         </button>
                    </div>
                </div>
            ) : (
                <div 
                    onClick={() => fileInputRef.current?.click()}
                    className="mt-1 flex justify-center px-6 pt-5 pb-6 border-2 border-gray-600 border-dashed rounded-md cursor-pointer hover:border-indigo-500 transition-colors duration-200 bg-gray-800"
                >
                    <div className="space-y-1 text-center">
                        <svg className="mx-auto h-12 w-12 text-gray-500" stroke="currentColor" fill="none" viewBox="0 0 48 48" aria-hidden="true">
                            <path d="M28 8H12a4 4 0 00-4 4v20m32-12v8m0 0v8a4 4 0 01-4 4H12a4 4 0 01-4-4v-4m32-4l-3.172-3.172a4 4 0 00-5.656 0L28 28M8 32l9.172-9.172a4 4 0 015.656 0L28 28m0 0l4 4m4-24h8m-4-4v8" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" />
                        </svg>
                        <div className="flex text-sm text-gray-500">
                            <p className="pl-1">צלם תמונה, בחר מהגלריה או לחץ לבחירה</p>
                            <input ref={fileInputRef} id={id} name={id} type="file" className="sr-only" onChange={handleFileChange} accept="image/*" capture="environment" />
                        </div>
                        <p className="text-xs text-gray-600">PNG, JPG, WEBP עד 10MB</p>
                    </div>
                </div>
            )}
        </div>
    );
};

export default ImageAreaSelector;
